from django.urls import path
from bca import views

app_name = 'bca'

urlpatterns = [
    path('home/', views.home, name='home'),

    # Function-Based Views (FBV) CRUD
    path('students/fbv/', views.student_list_fbv, name='student_list_fbv'),
    path('students/fbv/create/', views.student_create_fbv, name='student_create_fbv'),
    path('students/fbv/<int:pk>/', views.student_detail_fbv, name='student_detail_fbv'),
    path('students/fbv/<int:pk>/update/', views.student_update_fbv, name='student_update_fbv'),
    path('students/fbv/<int:pk>/delete/', views.student_delete_fbv, name='student_delete_fbv'),

    # Class-Based Views (CBV) CRUD
    path('students/cbv/', views.StudentListView.as_view(), name='student_list_cbv'),
    path('students/cbv/create/', views.StudentCreateView.as_view(), name='student_create_cbv'),
    path('students/cbv/<int:pk>/', views.StudentDetailView.as_view(), name='student_detail_cbv'),
    path('students/cbv/<int:pk>/update/', views.StudentUpdateView.as_view(), name='student_update_cbv'),
    path('students/cbv/<int:pk>/delete/', views.StudentDeleteView.as_view(), name='student_delete_cbv'),
]
