from django import forms
from bca.models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name', 'university_number']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter student name',
            }),
            'university_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter unique university number (e.g. U2026001)',
            }),
        }
