"""
URL configuration for bcakl project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from . import views

from django.urls import path, include
from . import views


urlpatterns = [
    path("admin/", admin.site.urls),
    path("home/", views.home, name="home"),
    path("products/", views.products, name="products"),
    path("service/", views.service, name="service"),
    path("contacts/", views.contacts, name="contacts"),
    path("", include("bcaai.urls")),  # Include the app's URLs
    path("", include("accounts.urls")),  # Include the accounts app's URLs



]
