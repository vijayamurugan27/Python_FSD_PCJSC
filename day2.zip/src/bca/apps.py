from django.apps import AppConfig


class BcaConfig(AppConfig):
    name = "bca"
