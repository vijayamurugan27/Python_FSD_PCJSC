from django.contrib import admin

# Register your models here.

from bca.models import Student
admin.site.register(Student)    