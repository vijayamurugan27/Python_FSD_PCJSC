from django.views.generic import (
    ListView, DetailView, CreateView,
    UpdateView, DeleteView
)
from django.urls import reverse_lazy
from .models import Employee


# Display all employees
class EmployeeListView(ListView):
    model = Employee
    template_name = 'employee_list.html'
    context_object_name = 'employees'


# Display single employee
class EmployeeDetailView(DetailView):
    model = Employee
    template_name = 'employee_detail.html'
    context_object_name = 'employee'


# Add new employee
class EmployeeCreateView(CreateView):
    model = Employee
    fields = '__all__'
    template_name = 'employee_form.html'
    success_url = reverse_lazy('employee_list')


# Update employee
class EmployeeUpdateView(UpdateView):
    model = Employee
    fields = '__all__'
    template_name = 'employee_form.html'
    success_url = reverse_lazy('employee_list')


# Delete employee
class EmployeeDeleteView(DeleteView):
    model = Employee
    template_name = 'employee_confirm_delete.html'
    success_url = reverse_lazy('employee_list')