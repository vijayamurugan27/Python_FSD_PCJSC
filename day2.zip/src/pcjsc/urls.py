"""
URL configuration for pcjsc project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
"""

from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", RedirectView.as_view(pattern_name="bca:home", permanent=False), name="root"),
    path("bca/", include("bca.urls")),
    path("mca/", include("mca.urls")),
]
