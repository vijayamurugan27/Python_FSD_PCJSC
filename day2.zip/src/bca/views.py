from django.shortcuts import render
from bca.models import Student

def home(request):
    students = Student.objects.all()
    return render(request, 'bca/home.html', {'students': students})
