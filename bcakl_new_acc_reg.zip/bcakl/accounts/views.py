from django.shortcuts import render, redirect
from django.contrib.auth import login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from accounts.forms import UserRegisterForm, UserLoginForm, SessionNoteForm

def register_view(request):
    """User Registration: creates account and logs user in directly"""
    if request.user.is_authenticated:
        return redirect('accounts:profile')

    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            # Initialize session variables
            request.session['visit_count'] = 1
            request.session['user_role'] = 'Student/User'
            messages.success(request, f"Welcome {user.username}! Your account has been created and you are now logged in.")
            return redirect('accounts:profile')
    else:
        form = UserRegisterForm()

    return render(request, 'accounts/register.html', {'form': form, 'title': 'Register New Account'})


def login_view(request):
    """User Login: authenticates credentials and creates session"""
    if request.user.is_authenticated:
        return redirect('accounts:profile')

    if request.method == 'POST':
        form = UserLoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)

            # Session tracking
            current_logins = request.session.get('login_count', 0) + 1
            request.session['login_count'] = current_logins
            request.session['visit_count'] = request.session.get('visit_count', 0) + 1

            messages.success(request, f"Welcome back, {user.username}! Successfully logged in.")

            # Redirect to next URL if provided, else profile
            next_url = request.GET.get('next') or request.POST.get('next')
            if next_url and next_url.startswith('/'):
                return redirect(next_url)
            return redirect('accounts:profile')
    else:
        form = UserLoginForm()

    return render(request, 'accounts/login.html', {'form': form, 'title': 'User Login'})


def logout_view(request):
    """User Logout: terminates active session"""
    if request.user.is_authenticated:
        username = request.user.username
        auth_logout(request)
        messages.info(request, f"Goodbye {username}! You have been logged out successfully.")
    else:
        auth_logout(request)

    return redirect('accounts:login')


@login_required
def profile_view(request):
    """User Profile & Session Inspector: displays user data and active session metrics"""
    # Track page visits inside active session
    visit_count = request.session.get('visit_count', 0) + 1
    request.session['visit_count'] = visit_count

    # Handle session note submission
    if request.method == 'POST':
        note_form = SessionNoteForm(request.POST)
        if note_form.is_valid():
            request.session['custom_note'] = note_form.cleaned_data['note']
            messages.success(request, "Custom note saved directly into your current session!")
            return redirect('accounts:profile')
    else:
        initial_note = request.session.get('custom_note', '')
        note_form = SessionNoteForm(initial={'note': initial_note})

    session_data = {
        'session_key': request.session.session_key,
        'visit_count': visit_count,
        'login_count': request.session.get('login_count', 1),
        'custom_note': request.session.get('custom_note', None),
        'expiry_date': request.session.get_expiry_date(),
        'expiry_age_seconds': request.session.get_expiry_age(),
        'all_session_keys': list(request.session.keys()),
    }

    context = {
        'title': f"Profile & Session: {request.user.username}",
        'user': request.user,
        'session_data': session_data,
        'note_form': note_form,
    }
    return render(request, 'accounts/profile.html', context)


@login_required
def clear_session_note_view(request):
    """Clears custom note from the session"""
    if 'custom_note' in request.session:
        del request.session['custom_note']
        messages.info(request, "Session note cleared.")
    return redirect('accounts:profile')
