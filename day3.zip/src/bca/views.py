from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.contrib import messages
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from bca.models import Student
from bca.forms import StudentForm

def home(request):
    students = Student.objects.all()
    return render(request, 'bca/home.html', {'students': students})


# ==========================================
# FUNCTION-BASED VIEWS (FBV) CRUD
# ==========================================

def student_list_fbv(request):
    """FBV: Display list of all students"""
    students = Student.objects.all()
    context = {
        'students': students,
        'view_mode': 'fbv',
        'title': 'Student List (FBV)',
    }
    return render(request, 'bca/student_list.html', context)


def student_detail_fbv(request, pk):
    """FBV: Display details for a single student"""
    student = get_object_or_404(Student, pk=pk)
    context = {
        'student': student,
        'view_mode': 'fbv',
        'title': f'Student Details: {student.name} (FBV)',
    }
    return render(request, 'bca/student_detail.html', context)


def student_create_fbv(request):
    """FBV: Create a new student"""
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save()
            messages.success(request, f'Student "{student.name}" created successfully via FBV!')
            return redirect('bca:student_list_fbv')
    else:
        form = StudentForm()

    context = {
        'form': form,
        'view_mode': 'fbv',
        'title': 'Create Student (FBV)',
    }
    return render(request, 'bca/student_form.html', context)


def student_update_fbv(request, pk):
    """FBV: Update an existing student"""
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            student = form.save()
            messages.success(request, f'Student "{student.name}" updated successfully via FBV!')
            return redirect('bca:student_list_fbv')
    else:
        form = StudentForm(instance=student)

    context = {
        'form': form,
        'student': student,
        'view_mode': 'fbv',
        'title': f'Update Student: {student.name} (FBV)',
    }
    return render(request, 'bca/student_form.html', context)


def student_delete_fbv(request, pk):
    """FBV: Delete an existing student"""
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student_name = student.name
        student.delete()
        messages.success(request, f'Student "{student_name}" deleted successfully via FBV!')
        return redirect('bca:student_list_fbv')

    context = {
        'student': student,
        'view_mode': 'fbv',
        'title': f'Delete Student: {student.name} (FBV)',
    }
    return render(request, 'bca/student_confirm_delete.html', context)


# ==========================================
# CLASS-BASED VIEWS (CBV) CRUD
# ==========================================

class StudentListView(ListView):
    """CBV: Display list of all students"""
    model = Student
    template_name = 'bca/student_list.html'
    context_object_name = 'students'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['view_mode'] = 'cbv'
        context['title'] = 'Student List (CBV)'
        return context


class StudentDetailView(DetailView):
    """CBV: Display details for a single student"""
    model = Student
    template_name = 'bca/student_detail.html'
    context_object_name = 'student'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['view_mode'] = 'cbv'
        context['title'] = f'Student Details: {self.object.name} (CBV)'
        return context


class StudentCreateView(CreateView):
    """CBV: Create a new student"""
    model = Student
    form_class = StudentForm
    template_name = 'bca/student_form.html'
    success_url = reverse_lazy('bca:student_list_cbv')

    def form_valid(self, form):
        messages.success(self.request, f'Student "{form.instance.name}" created successfully via CBV!')
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['view_mode'] = 'cbv'
        context['title'] = 'Create Student (CBV)'
        return context


class StudentUpdateView(UpdateView):
    """CBV: Update an existing student"""
    model = Student
    form_class = StudentForm
    template_name = 'bca/student_form.html'
    success_url = reverse_lazy('bca:student_list_cbv')

    def form_valid(self, form):
        messages.success(self.request, f'Student "{form.instance.name}" updated successfully via CBV!')
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['view_mode'] = 'cbv'
        context['title'] = f'Update Student: {self.object.name} (CBV)'
        return context


class StudentDeleteView(DeleteView):
    """CBV: Delete an existing student"""
    model = Student
    template_name = 'bca/student_confirm_delete.html'
    success_url = reverse_lazy('bca:student_list_cbv')
    context_object_name = 'student'

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        student_name = self.object.name
        messages.success(request, f'Student "{student_name}" deleted successfully via CBV!')
        return super().post(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['view_mode'] = 'cbv'
        context['title'] = f'Delete Student: {self.object.name} (CBV)'
        return context
