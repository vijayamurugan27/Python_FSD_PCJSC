from django.shortcuts import render

# Create your views here.
def products(request):
    return render(request, 'mca/products.html')


def contacts(request):
    return render(request, 'mca/contacts.html')