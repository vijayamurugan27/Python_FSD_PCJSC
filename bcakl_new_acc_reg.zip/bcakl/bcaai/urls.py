from django.urls import path
from . import views

urlpatterns = [
    # Display all employees
    path('', views.EmployeeListView.as_view(), name='employee_list'),

    # Display one employee
    path('detail/<int:pk>/', views.EmployeeDetailView.as_view(), name='employee_detail'),

    # Create employee
    path('create/', views.EmployeeCreateView.as_view(), name='employee_create'),

    # Update employee
    path('update/<int:pk>/', views.EmployeeUpdateView.as_view(), name='employee_update'),

    # Delete employee
    path('delete/<int:pk>/', views.EmployeeDeleteView.as_view(), name='employee_delete'),
]