from django.contrib import admin

# Register your models here.

from bcaai.models import Employee
admin.site.register(Employee)