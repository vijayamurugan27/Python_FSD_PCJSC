from django.urls import path, include
from . import views

from rest_framework.routers import DefaultRouter #for viewsets
router = DefaultRouter()
router.register(r'employees', views.EmployeeViewSet)

urlpatterns = [
    #DRF API URLs
    path('api/', include(router.urls)),
    
    # Display all employees
    path('', views.EmployeeListView.as_view(), name='employee_list'),

    # Display one employee
    path('detail/<int:pk>/', views.EmployeeDetailView.as_view(), name='employee_detail'),

    # Create employee
    path('create/', views.EmployeeCreateView.as_view(), name='employee_create'),

    # Update employee
    path('update/<int:pk>/', views.EmployeeUpdateView.as_view(), name='employee_update'),

    # Delete employee
    path('delete/<int:pk>/', views.EmployeeDeleteView.as_view(), name='employee_delete'),


]