from django.db import models

# Create your models here.

class Student(models.Model):
    name = models.CharField(max_length=150)
    university_number = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return f"{self.name} ({self.university_number})"
