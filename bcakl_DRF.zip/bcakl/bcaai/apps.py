from django.apps import AppConfig


class BcaaiConfig(AppConfig):
    name = "bcaai"
